DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;
CREATE SCHEMA IF NOT EXISTS auth;
DO $$ BEGIN CREATE ROLE authenticated NOLOGIN; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE ROLE anon NOLOGIN; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
GRANT ALL ON SCHEMA public, auth TO authenticated, anon;
CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$ SELECT nullif(current_setting('app.uid', true),'')::uuid $$;
CREATE TABLE public.empresa_config(id serial primary key, nombre text);
CREATE TABLE public.users(id serial primary key, auth_id uuid, nombre text, role text, active boolean default true);
CREATE TABLE public.contacts(id serial primary key, nombre text);
CREATE TABLE public.empleados(id serial primary key, empresa_id int, contact_id int, user_id int, estado text default 'activo');
CREATE FUNCTION public.fn_is_admin() RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER AS $$ SELECT EXISTS(SELECT 1 FROM public.users WHERE auth_id=auth.uid() AND role='admin') $$;
GRANT USAGE ON SCHEMA public TO authenticated, anon;
INSERT INTO empresa_config(nombre) VALUES ('Jhiro'),('Benji');
INSERT INTO users(auth_id,nombre,role) VALUES
 ('00000000-0000-0000-0000-000000000001','Luis Admin','admin'),
 ('00000000-0000-0000-0000-000000000002','Ana Jefa','user'),
 ('00000000-0000-0000-0000-000000000003','Beto Colab','user'),
 ('00000000-0000-0000-0000-000000000004','Carla Colab','user');
INSERT INTO contacts(nombre) VALUES ('Luis Admin'),('Ana Jefa'),('Beto Colab'),('Carla Colab'),('Dario SinCuenta');
INSERT INTO empleados(empresa_id,contact_id,user_id) VALUES (1,1,1),(1,2,2),(1,3,3),(1,4,4),(1,5,NULL);
