\set ON_ERROR_STOP 0
\pset tuples_only on
-- jefe de área
UPDATE empleados SET area='Contabilidad', es_jefe_area=true WHERE id=2;
UPDATE empleados SET area='Contabilidad' WHERE id IN (3);
UPDATE empleados SET area='Ventas' WHERE id IN (4,5);
CREATE OR REPLACE FUNCTION pg_temp.as_(n int) RETURNS void LANGUAGE sql AS $$ SELECT set_config('app.uid', '00000000-0000-0000-0000-00000000000'||n, false) $$;
\echo '--- 1 admin crea tarea para Beto (id3) ---'
SELECT pg_temp.as_(1); SET ROLE authenticated;
SELECT tareas_crear(1,'Conciliar banco BCP',3,current_date+2,'detalle',NULL,'alta');
SELECT tareas_crear(1,'Cobrar letra 42',4,current_date-3);
\echo '--- 2 Beto ve solo lo suyo (esperado 1) ---'
RESET ROLE; SELECT pg_temp.as_(3); SET ROLE authenticated;
SELECT count(*) FROM tareas;
SELECT jsonb_array_length(tareas_listar('mias'));
\echo '--- 3 Carla (Ventas) ve 1 (la suya) ; no ve la de Beto ---'
RESET ROLE; SELECT pg_temp.as_(4); SET ROLE authenticated;
SELECT count(*), string_agg(titulo,',') FROM tareas;
\echo '--- 4 Carla no puede escribir directo (esperado error) ---'
UPDATE tareas SET estado='hecha';
INSERT INTO tareas(empresa_id,titulo,solicitante_id) VALUES (1,'hack',4);
RESET ROLE;
CREATE TEMP TABLE ids AS SELECT id, titulo FROM tareas;
GRANT SELECT ON ids TO authenticated;
SELECT pg_temp.as_(4); SET ROLE authenticated;
SELECT tareas_cambiar_estado((SELECT id FROM ids WHERE titulo LIKE 'Conciliar%'), 'hecha');
\echo '--- 6 Carla (responsable de letra) pasa a en_proceso, luego bloquea esperando a Beto ---'
SELECT tareas_cambiar_estado((SELECT id FROM ids WHERE titulo LIKE 'Cobrar%'), 'en_proceso');
SELECT tareas_bloquear((SELECT id FROM ids WHERE titulo LIKE 'Cobrar%'), 3, 'Falta voucher');
SELECT tareas_bloquear((SELECT id FROM ids WHERE titulo LIKE 'Cobrar%'), 4, 'x yz');
SELECT tareas_cambiar_estado((SELECT id FROM ids WHERE titulo LIKE 'Cobrar%'), 'hecha');
\echo '--- 7 Beto (bloqueador) ahora ve 2 tareas, avisos incluye te_bloquea, y puede desbloquear ---'
RESET ROLE; SELECT pg_temp.as_(3); SET ROLE authenticated;
SELECT count(*) FROM tareas;
SELECT jsonb_path_query_array(tareas_avisos(), '$[*].tipo');
SELECT tareas_mis_numeros();
SELECT tareas_desbloquear((SELECT id FROM ids WHERE titulo LIKE 'Cobrar%'));
\echo '--- 8 Beto no puede reasignar ni anular lo ajeno ---'
SELECT tareas_reasignar((SELECT id FROM ids WHERE titulo LIKE 'Conciliar%'), 4);
SELECT tareas_listar('gerencia');
\echo '--- 9 jefe Ana (Contabilidad) ve Conciliar pero no Cobrar (Ventas) ---'
RESET ROLE; SELECT pg_temp.as_(2); SET ROLE authenticated;
SELECT count(*), string_agg(titulo,',') FROM tareas;
SELECT tareas_kpis();
SELECT tareas_reasignar((SELECT id FROM ids WHERE titulo LIKE 'Conciliar%'), 2, 'la llevo yo');
\echo '--- 10 admin gerencia ve 2, kpis ---'
RESET ROLE; SELECT pg_temp.as_(1); SET ROLE authenticated;
SELECT jsonb_array_length(tareas_listar('gerencia')), tareas_kpis();
\echo '--- 11 bitacora Conciliar ---'
SELECT jsonb_path_query_array(tareas_bitacora_de((SELECT id FROM ids WHERE titulo LIKE 'Conciliar%')), '$[*].tipo');
\echo '--- 12 recurrentes: crear, generar x2 idempotente; colaborador no puede ---'
SELECT tareas_recurrente_guardar(NULL,1,'Cierre IGV',NULL,'Contabilidad',3,'mensual',31);
SELECT tareas_recurrente_guardar(NULL,1,'Arqueo caja',NULL,'Ventas',4,'diaria',NULL);
SELECT tareas_generar_recurrentes();
SELECT tareas_generar_recurrentes();
SELECT count(*) FROM tareas WHERE recurrente_id IS NOT NULL;
RESET ROLE; SELECT pg_temp.as_(3); SET ROLE authenticated;
SELECT tareas_recurrente_guardar(NULL,1,'Mala',NULL,'Contabilidad',3,'diaria',NULL);
SELECT tareas_listar('gerencia');
\echo '--- 13 anon no ejecuta ---'
RESET ROLE; SET ROLE anon;
SELECT tareas_mis_numeros();
SELECT count(*) FROM tareas;
