const { chromium } = require('playwright');
const { execFileSync } = require('child_process');
const http = require('http'), fs = require('fs'), path = require('path');
const root = '/home/claude/genko-tareas/erp_v2';
const srv = http.createServer((q, r) => { let p = path.join(root, decodeURIComponent(q.url.split('?')[0])); if (!fs.existsSync(p)) { r.statusCode = 404; return r.end(); }
  r.setHeader('Content-Type', p.endsWith('.js') ? 'text/javascript' : p.endsWith('.css') ? 'text/css' : 'text/html'); r.end(fs.readFileSync(p)); }).listen(5599);
const UIDS = { admin: '00000000-0000-0000-0000-000000000001', ana: '00000000-0000-0000-0000-000000000002', beto: '00000000-0000-0000-0000-000000000003' };
function rpc(uid, fn, args) {
  const names = Object.keys(args || {}); const vals = names.map((n) => args[n]);
  const lit = (v) => v === null || v === undefined ? 'NULL' : Array.isArray(v) ? `'{${v.join(',')}}'` : typeof v === 'number' ? v : `'${String(v).replace(/'/g, "''")}'`;
  const call = `${fn}(${names.map((n, i) => `${n} => ${lit(vals[i])}`).join(',')})`;
  const sql = `SET app.uid='${uid}'; SET ROLE authenticated; SELECT ${call};`;
  try { const out = execFileSync('su', ['postgres', '-c', `psql -d t161 -tA -q -c "${sql.replace(/"/g, '\\"')}"`], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    const line = out.split('\n').filter((l) => l && !l.startsWith('SET'))[0] || 'null'; return { data: JSON.parse(line) }; }
  catch (e) { const m = String(e.stderr).match(/ERROR:\s*(.*)/); return { error: { message: m ? m[1] : String(e.stderr) } }; }
}
(async () => {
  const b = await chromium.launch(); const res = {};
  for (const [who, uid] of Object.entries({ beto: UIDS.beto, admin: UIDS.admin })) {
    const pg = await b.newPage({ viewport: { width: 1200, height: 800 } }); const errs = [];
    pg.on('pageerror', (e) => errs.push(e.message)); pg.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
    await pg.exposeFunction('__rpc', (fn, args) => rpc(uid, fn, args));
    await pg.addInitScript(() => { window.__tk_stub = { rpc: (fn, a) => window.__rpc(fn, a) }; });
    await pg.goto('http://localhost:5599/tareas.html'); await pg.waitForTimeout(2500);
    res[who] = { filas: await pg.locator('#tk-lista tbody tr').count(), gerenciaTab: await pg.locator('#tk-tab-gerencia').isVisible(), errs };
    if (who === 'admin') {
      await pg.click('#tk-tab-gerencia'); await pg.waitForTimeout(1500);
      res.admin.gerFilas = await pg.locator('#tk-lista tbody tr').count(); res.admin.kpis = await pg.locator('.tk-kpi').count();
      await pg.click('#tk-btn-nueva'); await pg.fill('#n-tit', 'Tarea desde UI'); await pg.selectOption('#n-resp', { label: 'Dario SinCuenta · Ventas (sin cuenta)' }); await pg.click('#n-ok'); await pg.waitForTimeout(1500);
      res.admin.tras_crear = await pg.locator('#tk-lista tbody tr').count();
      await pg.locator('#tk-lista tbody tr', { hasText: 'Tarea desde UI' }).click(); await pg.waitForTimeout(800);
      res.admin.botones = await pg.locator('#d-acc button').allTextContents();
      await pg.screenshot({ path: '/tmp/tk_detalle.png' });
    } else await pg.screenshot({ path: '/tmp/tk_beto.png' });
  }
  console.log(JSON.stringify(res, null, 1)); await b.close(); srv.close();
})();
