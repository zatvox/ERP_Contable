// init.js — arranque de tareas.html. Ajustar SOLO obtenerCliente() al cliente real del ERP al conectar.
import { setClient } from './tareas-data.js';
import { iniciar } from './tareas-ui.js';

async function obtenerCliente() {
  // TODO(verificar al conectar): reemplazar por el import real del ERP, p. ej.:
  //   const { supabase } = await import('../supabase.js'); return supabase;
  if (window.__tk_stub) return window.__tk_stub;           // arnés de pruebas
  const mod = await import('../supabase.js');
  return mod.supabase || mod.default;
}

(async () => {
  setClient(await obtenerCliente());
  // empresa de trabajo: usa la que ya guarda el ERP si existe (multiempresa); si no, 1
  const empresaId = Number(window.empresaTrabajo?.id ?? window.empresaTrabajo ?? localStorage.getItem('empresaTrabajo') ?? 1) || 1;
  await iniciar({ empresaId });
})();
